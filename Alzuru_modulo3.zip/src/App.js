import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import {BrowserRouter as Router} from 'react-router-dom'
import Public from './Routes/Public';
import AuthProvider from './Context/AuthContext';

function App() {
  return (
    <div className="App">
      <Router>
        <AuthProvider>
          <Public/>
        </AuthProvider>
      </Router>
    </div>
  );
}

export default App;
