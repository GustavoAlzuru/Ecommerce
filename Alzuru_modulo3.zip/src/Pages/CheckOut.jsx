import PlainNav from "../Components/Navigation/PlainNav"
import { useParams } from "react-router-dom";
import { getProduct } from "../Services/ProductServices";
import { useEffect, useState } from "react";

function CheckOut(){
    const {id} = useParams()
    const [product, setProduct] = useState({})
    useEffect(
        () => {
            const product = async () => {
                const data = await getProduct(id)
                setProduct(data)
            }   
            product() 
        },
        [id]
    )
    // console.log(product)
//    product.pictures?.map(img => console.log(img.url))
// console.log(product.pictures[0]?.url)
    return(
    <>
        <PlainNav/>
        <div className="mainBackground">
            <h3>{product.title}</h3>
            {/* <img src={product.pictures[0].url} alt="" /> */}
            {/* {product.pictures?.map(img => <img src={img.url}/>)} */}
            {/* <img src={} alt="" /> */}
            <p>$ {product.price}</p>
        </div>
    </>
    ) 
}
export default CheckOut